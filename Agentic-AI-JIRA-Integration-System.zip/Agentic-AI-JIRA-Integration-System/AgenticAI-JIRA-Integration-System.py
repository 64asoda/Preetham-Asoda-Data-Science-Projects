import os
import asyncio
from pathlib import Path

from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.conditions import MaxMessageTermination, TextMentionTermination
from autogen_agentchat.teams import RoundRobinGroupChat
from autogen_agentchat.ui import Console
from autogen_ext.models.openai import OpenAIChatCompletionClient
from autogen_ext.tools.mcp import McpWorkbench, StdioServerParams

os.environ[
    "OPENAI_API_KEY"] = "OpenAI-API-Key"
os.environ["JIRA_URL"] = "https://preethamaiml.atlassian.net/"
os.environ["JIRA_USERNAME"] = "preetham.aiml@gmail.com"
os.environ[
    "JIRA_API_TOKEN"] = "JIRA-API-Key"
os.environ["JIRA_PROJECTS_FILTER"] = "C1"
# This creates an absolute path like: C:\Users\preet\PycharmProjects\AgenticAIAutogen\screenshots

# Python and Docker handle the formatting
local_screenshot_dir = Path("screenshots").resolve()

# This is the path inside the Docker container
docker_mount_path = "/mnt/screenshots"


async def main():
    model_client = OpenAIChatCompletionClient(
        model="gpt-5")
    jira_server_params = StdioServerParams(command="docker",
                                           args=[
                                               "run", "-i", "--rm",
                                               "-v", f"{local_screenshot_dir}:{docker_mount_path}",
                                               "-e", f"JIRA_URL={os.environ['JIRA_URL']}",
                                               "-e", f"JIRA_USERNAME={os.environ['JIRA_USERNAME']}",
                                               "-e", f"JIRA_API_TOKEN={os.environ['JIRA_API_TOKEN']}",
                                               "-e", f"JIRA_PROJECTS_FILTER={os.environ['JIRA_PROJECTS_FILTER']}",
                                                     "ghcr.io/sooperset/mcp-atlassian:latest"
                                           ])
    jira_workbench = McpWorkbench(jira_server_params)

    playwright_server_params = StdioServerParams(command="npx",
                                                 args=["@playwright/mcp@latest"])
    playwright_workbench = McpWorkbench(playwright_server_params)

    async with jira_workbench as jira_wb, playwright_workbench as playwright_wb:
        bug_analyst = AssistantAgent(name='BugAnalyst',
                                     model_client=model_client,
                                     workbench=jira_wb,
                                     system_message=(
                                                     "\n"
                                                     "You are a Bug Analyst specializing in Jira defect analysis.\n"
                                                     "\n"
                                                     "Your task is as follows:\n"
                                                     "Goal - - Your role is to analyze defects and create "
                                                     "comprehensive test scenarios.\n"
                                                     "1. Retrieve and review the most recent **5 bugs** from the "
                                                     "**CreditCardBanking-1 Project** (Project Key: `C1`) in Jira.\n"
                                                     "2. Carefully read their descriptions and identify **recurring "
                                                     "issues or common patterns**.\n"
                                                     "3. Based on these patterns, design a **detailed user flow** "
                                                     "that exercises the core features of the application and can "
                                                     "serve as a robust **smoke test scenario**.\n"
                                                     "\n"
                                                     "Be very specific in your smoke test design:\n"
                                                     "- Provide clear, step-by-step manual testing instructions.\n"
                                                     "- Include exact **URLs or page routes** to visit.\n"
                                                     "- Describe **user actions** (clicks, form inputs, submissions).\n"
                                                     "- Clearly state the **expected outcomes or validations** for "
                                                     "each step.\n"
                                                     "\n"
                                                     "If you detect **zero bugs** in the recent Jira query, attempt "
                                                     "to re-query or note it clearly.\n"
                                                     "\n"
                                                     "When your analysis and scenario preparation is complete:\n"
                                                     "- Clearly output the final smoke testing steps.\n"
                                                     "- Finally, write: **'HANDOFF TO AUTOMATION'** to signal "
                                                     "completion of your analysis.\n"
                                                     "\n"
                                                     "Thank you for your thorough analysis.\n"))

        automation_agent = AssistantAgent(name='AutomationAgent', model_client=model_client,
                                          workbench=playwright_wb,
                                          system_message="You are a Playwright automation expert. Take the user flow "
                                                         "from BugAnalyst"
                                                         "and convert it into executable Playwright commands. Use "
                                                         "Playwright"
                                                         "MCP tools to"
                                                         "execute the smoke test. Execute the automated test step by "
                                                         "step and report"
                                                         "results clearly, including any errors or successes. Take "
                                                         "screenshots at key"
                                                         "points to document the test execution."
                                                         "Make sure expected results in the bug are validated in your "
                                                         "flow"
                                                         "Important : Use browser_wait_for to wait for success/error "
                                                         "messages\n"
                                                         "- Wait for buttons to change state (e.g., 'Applying...' to "
                                                         "complete)\n"
                                                         "   - Verify expected outcomes as specified by BugAnalyst"
                                                         "Always follow the exact timing and waiting instructions "
                                                         "provided"
                                                         "Complete ALL steps before saying 'TESTING COMPLETE, Execute "
                                                         "each step fully, don't rush to completion")

    team = RoundRobinGroupChat(
                               participants=[bug_analyst, automation_agent],
                               termination_condition=TextMentionTermination("TESTING COMPLETE")
                              )
    await Console(team.run_stream(task="BugAnalyst: \n"
                                       "1. Search for recent bugs in CRED project\n"
                                       "2.Then design a stable user flow that can be used as a smoke test."
                                       "3. Use REAL URLs like: <Test-URL>"

                                       "AutomationAgent:\n"
                                       "Once ready, automate this flow using Playwright MCP and execute it."))
    await model_client.close()


asyncio.run(main())
